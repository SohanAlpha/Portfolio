# **App Name**: SkillSlate

## Core Features:

- Header Section: Displays name, title, contact details, and professional photo in a prominent header section.
- About Me Section: Presents an engaging summary highlighting skills and career objectives.
- Education Section: Lists educational background, including school name, status, score, and location.
- Skills Section: Visually showcases web development, programming languages, tools, and other skills using icons or labels.
- Projects Section: Highlights the 'Blockchain App' project with detailed description, key features, technologies used, and a link to GitHub or live demo.
- AI-Powered Bio Generation: Generates a professional-sounding summary statement given the user's resume/cv content as a tool, so that the summary can be added to the "About Me" Section. The AI tool should not use any first-person references, like "I" or "me."

## Style Guidelines:

- Primary color: Deep indigo (#4B0082) for a professional and trustworthy feel.
- Background color: Light lavender (#E6E6FA) providing a soft and clean backdrop.
- Accent color: Golden yellow (#FFD700) to highlight key information and calls to action.
- Body text: 'PT Sans', sans-serif, providing modern look.
- Headline Font: 'Playfair', serif. Pair it with 'PT Sans' for the body of the page.
- Use clean and professional icons to represent skills and sections.
- Subtle transitions and animations to enhance user experience when scrolling.