
"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { SudarshanLogo } from "@/components/logo";
import { Copy, Check } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from '@/components/ui/skeleton';

export default function RecoveryPhrasePage() {
  const router = useRouter();
  const { toast } = useToast();
  const [recoveryPhrase, setRecoveryPhrase] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      // Retrieve the phrase from session storage
      const phrase = sessionStorage.getItem('recoveryPhrase');
      if (phrase) {
        setRecoveryPhrase(phrase.split(' '));
      } else {
        // If no phrase is found, maybe the user navigated here directly
        toast({
          title: "No Recovery Phrase Found",
          description: "Please create an account first to get a recovery phrase.",
          variant: "destructive",
        });
        router.push('/create-account');
      }
    } catch (error) {
       console.error("Failed to load recovery phrase from storage:", error);
       toast({
           title: "Error",
           description: "Could not load your recovery phrase. Please go back and try again.",
           variant: "destructive",
       });
    } finally {
       setIsLoading(false);
    }
  }, [router, toast]);


  const handleCopy = () => {
    if (recoveryPhrase.length === 0) return;
    navigator.clipboard.writeText(recoveryPhrase.join(" "));
    setCopied(true);
    toast({
      title: "Copied to Clipboard",
      description: "Your recovery phrase has been copied.",
    });
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <main className="flex min-h-screen w-full flex-col items-center justify-center p-4">
      <div className="w-full max-w-md animate-in fade-in-0 zoom-in-95 duration-500 text-center">
        <div className="flex flex-col items-center justify-center mb-6">
          <SudarshanLogo />
           <h1 className="text-4xl font-bold tracking-tight text-muted-foreground sm:text-5xl font-headline mt-4">
            Sudarshan
          </h1>
        </div>

        <h2 className="text-3xl font-bold">Recovery Phrase</h2>
        <p className="mt-2 mb-6 text-lg text-muted-foreground max-w-xs mx-auto">
          Write down or copy these words in the correct order and store them in a safe place.
        </p>

        <div className="grid grid-cols-3 gap-4 p-6 rounded-lg bg-card border font-mono text-center min-h-[140px]">
          {isLoading ? (
            Array.from({ length: 12 }).map((_, index) => (
              <div key={index} className="flex items-center justify-center">
                <Skeleton className="h-5 w-20" />
              </div>
            ))
          ) : (
            recoveryPhrase.map((word, index) => (
              <div key={index} className="flex items-center justify-center">
                <span className="text-foreground">{word}</span>
              </div>
            ))
          )}
        </div>

        <div className="mt-8 flex flex-col gap-4">
            <Button size="lg" onClick={handleCopy} disabled={isLoading || copied || recoveryPhrase.length === 0}>
                {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                {copied ? 'Copied!' : 'Copy to Clipboard'}
            </Button>
        </div>
      </div>
    </main>
  );
}
